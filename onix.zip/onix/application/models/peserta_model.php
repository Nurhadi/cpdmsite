<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Peserta_model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
	}

	public function get_data_homepage()
	{
		$this->db->where("homepage_id", "1");
		$result = $this->db->get("homepage");
		return $result;
	}

	public function get_peserta()
	{
		$this->db->where("status !=", "deleted");
		$this->db->order_by("tanggal_dibuat", "desc");
		$result = $this->db->get("peserta");
		return $result;
	}

	public function get_data_peserta($peserta_id)
	{
		$this->db->where("id", $peserta_id);
		$result = $this->db->get("peserta");
		return $result;
	}

	public function daftar($nama_lengkap, $kategori, $nidn_nip, $tempat, $tanggal_lahir, $alamat, $instansi, $alamat_instansi, $no_handphone, $no_telepon, $email, $surat_tugas, $informasi_laboratorium_sekolah, $periode_pelatihan, $foto, $status, $tanggal_dibuat)
	{
		$data = array(
			'nama_lengkap' => $nama_lengkap,
			'kategori' => $kategori,
			'nidn_nip' => $nidn_nip,
			'tempat' => $tempat,
			'tanggal_lahir' => $tanggal_lahir,
			'alamat' => $alamat,
			'instansi' => $instansi,
			'alamat_instansi' => $alamat_instansi,
			'no_handphone' => $no_handphone,
			'no_telepon' => $no_telepon,
			'email' => $email,
			'surat_tugas' => $surat_tugas,
			'informasi_laboratorium_sekolah' => $informasi_laboratorium_sekolah,
			'periode_pelatihan' => $periode_pelatihan,
			'foto' => $foto,
			'status' => $status,
			'tanggal_dibuat' => $tanggal_dibuat,
		);

		$this->db->insert('peserta', $data);
		return($this->db->affected_rows() != 1) ? false : $this->db->insert_id();
	}

	public function create_new_peserta($title, $keywords, $description, $content, $promo, $admin_id)
	{
		$data = array("title" => $title, "keywords" => $keywords, "description" => $description, "content" => $content, "promo" => $promo, "admin_id" => $admin_id);
		$result = $this->db->insert("peserta", $data);
		return $this->db->insert_id();
	}

	public function update_peserta($peserta_id, $title, $keywords, $description, $content, $promo, $admin_id)
	{
		$data = array("title" => $title, "keywords" => $keywords, "description" => $description, "content" => $content, "promo" => $promo, "admin_id" => $admin_id);
		$this->db->where("peserta_id", $peserta_id);
		$result = $this->db->update("peserta", $data);
		return $result;
	}

	public function approve_peserta($peserta_id, $tanggal_disetujui)
	{
		$data = array("tanggal_disetujui" => $tanggal_disetujui, "status" => "approved");
		$this->db->where("id", $peserta_id);
		$this->db->update("peserta", $data);
		$this->db->trans_complete();

		if ($this->db->trans_status() !== FALSE)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	public function delete_status_peserta($peserta_id)
	{
		$data = array("status" => "deleted");
		$this->db->where("id", $peserta_id);
		$this->db->update("peserta", $data);
		$this->db->trans_complete();

		if ($this->db->trans_status() !== FALSE)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	public function upload_thumbnail($file_path, $peserta){
		$data = array("thumbnail" => $file_path);
		$this->db->where("peserta_id", $peserta);
		$result = $this->db->update("peserta", $data);
		return $result;
	}

	public function get_peserta_path($peserta_id){
		$this->db->select('thumbnail')->from('peserta')->where('peserta_id',$peserta_id);
    $query = $this->db->get();

    if ($query->num_rows() > 0) {
      return $query->row()->thumbnail;
    }
    return false;
	}
}

?>