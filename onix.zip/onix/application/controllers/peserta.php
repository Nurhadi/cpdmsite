<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Peserta extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('admin_model');
		$this->load->model('peserta_model');
		$this->load->model('page_model');
		$this->load->library('sidebar');
		// $this->output->enable_profiler(true);
	}

	public function index()
	{
		if($this->session->userdata('logged_in') == 1){
			$admin = $this->admin_model->get_data_admin($this->session->userdata('email'));
			foreach ($admin->result() as $row)
			{
				$data["fullname"] = $row->firstname . " " . $row->lastname;
			}

			$data["peserta"] = $this->peserta_model->get_peserta();

			$peserta = $this->page_model->get_data_page(1);
			foreach ($peserta->result() as $hp)
			{
				$data["title"] = $hp->title;
				$data["keywords"] = $hp->keywords;
				$data["description"] = $hp->description;
				$data["content"] = $hp->content;
			}

			// $data['unread_message'] = $this->sidebar->get_unread_message_count();
			$this->load->view('peserta_view', $data);
		}
		else
		{
			redirect('/login', 'refresh');
		}
	}

	public function peserta_process()
	{
		$nama_lengkap = $this->input->post('nama_lengkap');
		$kategori = $this->input->post('kategori');
		$nidn_nip = $this->input->post('nidn_nip');
		$tempat = $this->input->post('tempat');
		$tanggal_lahir = $this->input->post('tanggal_lahir');
		$alamat = $this->input->post('alamat');
		$instansi = $this->input->post('instansi');
		$alamat_instansi = $this->input->post('alamat_instansi');
		$no_handphone = $this->input->post('no_handphone');
		$no_telepon = $this->input->post('no_telepon');
		$email = $this->input->post('email');
		$periode_pelatihan = $this->input->post('periode_pelatihan');
		$status = 'pending';

		// attachment
		$config['upload_path'] = './uploads/pendaftaran/';
		$config['allowed_types'] = 'gif|jpg|png|doc|docx|pdf';
		$this->load->library('upload', $config);

		if (!$this->upload->do_upload('surat_tugas'))
		{
			$error = array('error' => $this->upload->display_errors());
		}
		else
		{
			$data = array('upload_data' => $this->upload->data());
			$surat_tugas = $data['upload_data']['file_name'];
		}

		if (!$this->upload->do_upload('informasi_laboratorium_sekolah'))
		{
			$error = array('error' => $this->upload->display_errors());
		}
		else
		{
			$data = array('upload_data' => $this->upload->data());
			$informasi_laboratorium_sekolah = $data['upload_data']['file_name'];
		}

		if (!$this->upload->do_upload('foto'))
		{
			$error = array('error' => $this->upload->display_errors());
		}
		else
		{
			$data = array('upload_data' => $this->upload->data());
			$foto = $data['upload_data']['file_name'];
		}

		if($this->input->post("form_action") === "create"){
			$this->load->helper('date');
			date_default_timezone_set("Asia/Jakarta");
			$tanggal_dibuat = date("Y-m-d H:i:s");

			$daftar =	$this->peserta_model->daftar($nama_lengkap, $kategori, $nidn_nip, $tempat, $tanggal_lahir, $alamat, $instansi, $alamat_instansi, $no_handphone, $no_telepon, $email, $surat_tugas, $informasi_laboratorium_sekolah, $periode_pelatihan, $foto, $status, $tanggal_dibuat);
		}
		// else{
		// 	$peserta_id = $this->input->post("peserta_id");
		// 	$peserta = $this->peserta_model->update_peserta($peserta_id, $title, $keywords, $description, $content, $promo, $admin_id);
		// }


		if($peserta){
			$config['upload_path'] = './../assets/uploads/peserta/';
			$config['allowed_types'] = 'gif|jpg|png|jpeg|';

			$this->load->library('upload', $config);

			if (!$this->upload->do_upload("thumbnail"))
			{
				if($thumbnail === true){
					$this->session->set_flashdata("status", $this->upload->display_errors());
					redirect("peserta");
				}
				else{
					$this->session->set_flashdata("status", "Success update data peserta");
					redirect("peserta");
				}
			}
			else
			{
				$old_thumbnail_path = $this->peserta_model->get_peserta_path($peserta_id);
				if($old_thumbnail_path){
					unlink("./../".$old_thumbnail_path);
				}

				$data = array('upload_data' => $this->upload->data());
				$file_path = "assets/uploads/peserta/" . $data["upload_data"]["file_name"];
				$upload_slider = $this->peserta_model->upload_thumbnail($file_path, $peserta_id);

				$this->session->set_flashdata("status", "Success create data peserta");
				redirect("peserta");
			}
		}
		else{
			$this->session->set_flashdata("status", "Error");
			redirect("peserta");
		}
	}

	// create peserta ajax
	// public function create_new_peserta()
	// {
	// 	$title = $this->input->post("title");
	// 	$keywords = $this->input->post("keywords");
	// 	$description = $this->input->post("description");
	// 	$thumbnail = $this->input->post("thumbnail");
	// 	$content = $this->input->post("content");
	// 	$promo = $this->input->post("promo");
	// 	$admin_id = $this->admin_model->get_admin_id($this->session->userdata('email'));

	// 	$new_peserta = $this->peserta_model->create_new_peserta($title, $keywords, $description, $thumbnail, $content, $promo, $admin_id);

	// 	if($new_peserta){
	// 		echo "success";
	// 	}
	// 	else{
	// 		echo "error";
	// 	}
	// }

	public function detail_peserta()
	{
		$peserta_id = $this->input->post("peserta_id");

		$peserta = $this->peserta_model->get_data_peserta($peserta_id);
		foreach ($peserta->result() as $p)
		{
			$kategori = $p->kategori;
			$nama_lengkap = $p->nama_lengkap;
			$nidn_nip = $p->nidn_nip;
			$tempat = $p->tempat;
			$tanggal_lahir = $p->tanggal_lahir;
			$alamat = $p->alamat;
			$instansi = $p->instansi;
			$alamat_instansi = $p->alamat_instansi;
			$no_telepon = $p->no_telepon;
			$no_handphone = $p->no_handphone;
			$email = $p->email;
			$surat_tugas = $p->surat_tugas;
			$informasi_laboratorium_sekolah = $p->informasi_laboratorium_sekolah;
			$periode_pelatihan = $p->periode_pelatihan;
			$foto = $p->foto;
			$status = $p->status;
			$tanggal_dibuat = $p->tanggal_dibuat;
			$bukti_pembayaran = $p->bukti_pembayaran;
			$tanggal_konfirmasi = $p->tanggal_konfirmasi;
			$tanggal_disetujui = $p->tanggal_disetujui;
		}

		echo $kategori.'|'.$nama_lengkap.'|'.$nidn_nip.'|'.$tempat.'|'.date("d/m/Y", strtotime($tanggal_lahir)).'|'.$alamat.'|'.$instansi.'|'.$alamat_instansi.'|'.$no_telepon.'|'.$no_handphone.'|'.$email.'|'.$surat_tugas.'|'.$informasi_laboratorium_sekolah.'|'.$periode_pelatihan.'|'.$foto.'|'.$status.'|'.date("d/m/Y H:i:s", strtotime($tanggal_dibuat)).'|'.$bukti_pembayaran.'|'.date("d/m/Y H:i:s", strtotime($tanggal_konfirmasi)).'|'.date("d/m/Y H:i:s", strtotime($tanggal_disetujui));
	}

	public function edit_peserta()
	{
		$peserta_id = $this->input->post("peserta_id");

		$peserta = $this->peserta_model->get_data_peserta($peserta_id);
		foreach ($peserta->result() as $p)
		{
			$kategori = $p->kategori;
			$nama_lengkap = $p->nama_lengkap;
			$nidn_nip = $p->nidn_nip;
			$tempat = $p->tempat;
			$tanggal_lahir = $p->tanggal_lahir;
			$alamat = $p->alamat;
			$instansi = $p->instansi;
			$alamat_instansi = $p->alamat_instansi;
			$no_telepon = $p->no_telepon;
			$no_handphone = $p->no_handphone;
			$email = $p->email;
			$surat_tugas = $p->surat_tugas;
			$informasi_laboratorium_sekolah = $p->informasi_laboratorium_sekolah;
			$periode_pelatihan = $p->periode_pelatihan;
			$foto = $p->foto;
			$status = $p->status;
			$tanggal_dibuat = $p->tanggal_dibuat;
			$bukti_pembayaran = $p->bukti_pembayaran;
			$tanggal_konfirmasi = $p->tanggal_konfirmasi;
			$tanggal_disetujui = $p->tanggal_disetujui;
		}

		echo $kategori.'|'.$nama_lengkap.'|'.$nidn_nip.'|'.$tempat.'|'.date("d/m/Y", strtotime($tanggal_lahir)).'|'.$alamat.'|'.$instansi.'|'.$alamat_instansi.'|'.$no_telepon.'|'.$no_handphone.'|'.$email.'|'.$surat_tugas.'|'.$informasi_laboratorium_sekolah.'|'.$periode_pelatihan.'|'.$foto.'|'.$status.'|'.date("d/m/Y H:i:s", strtotime($tanggal_dibuat)).'|'.$bukti_pembayaran.'|'.date("d/m/Y H:i:s", strtotime($tanggal_konfirmasi)).'|'.date("d/m/Y H:i:s", strtotime($tanggal_disetujui));
	}

	public function update_peserta()
	{
		$peserta_id = $this->input->post("peserta_id");
		$title = $this->input->post("title");
		$keywords = $this->input->post("keywords");
		$description = $this->input->post("description");
		$thumbnail = $this->input->post("thumbnail");
		$content = $this->input->post("content");
		$promo = $this->input->post("promo");
		$admin_id = $this->admin_model->get_admin_id($this->session->userdata('email'));

		$update_peserta = $this->peserta_model->update_peserta($peserta_id, $title, $keywords, $description, $thumbnail, $content, $promo, $admin_id);

		if($update_peserta){
			echo "success";
		}
		else{
			echo "error";
		}
	}

	public function approve_peserta()
	{
		$peserta_id = $this->input->post("peserta_id");

		$this->load->helper('date');
		date_default_timezone_set("Asia/Jakarta");
		$tanggal_disetujui = date("Y-m-d H:i:s");

		$peserta = $this->peserta_model->approve_peserta($peserta_id, $tanggal_disetujui);

		if($peserta === true){
			echo "success";
		}
		else{
			echo "error";
		}
	}

	public function delete_peserta()
	{
		$peserta_id = $this->input->post("peserta_id");
		$peserta = $this->peserta_model->delete_status_peserta($peserta_id);

		if($peserta === true){
			echo "success";
		}
		else{
			echo "error";
		}
	}
}

/* End of file peserta.php */
/* Location: ./application/controllers/peserta.php */