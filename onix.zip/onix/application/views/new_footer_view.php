	<!-- SB Admin Scripts - Include with every page -->
	<script src="<?php echo base_url('assets/scripts/sb-admin.js');?>"></script>

</body>

</html>
