			<div class="col-md-2" id="box-main-menu">
				<p class="mar-top-10">Dental Zone Administrator</p>
				<div class="row">
					<div class="col-md-12 box-full">
						<div class="box-title">
							Menu
						</div>
						<div class="box-content">
							<div class="col-md-12"><a href="<?php echo site_url('admin');?>">Dashboard</a></div>
							<div class="col-md-12"><a href="<?php echo site_url('homepage');?>">Home Page</a></div>
							<div class="col-md-12"><a href="<?php echo site_url('berita');?>">Berita</a></div>
							<div class="col-md-12"><a href="<?php echo site_url('profile');?>">Profile</a></div>
							<div class="col-md-12"><a href="<?php echo site_url('jadwal-praktek');?>">Jadwal Praktek</a></div>
							<div class="col-md-12"><a href="<?php echo site_url('tentang-kami');?>">Tentang Kami</a></div>
						</div>
					</div>
				</div>
			</div>