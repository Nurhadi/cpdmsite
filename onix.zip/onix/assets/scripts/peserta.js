$(document).ready(function(){
	// data table
	$('#peserta').dataTable();

	// redactor
	$('#redactor').redactor({
		focus: true,
		minHeight: 125
	});

	// title
	$("#text-edit-title").click(function(){
		$("#box-display-title").hide();
		$("#box-edit-title").fadeIn("slow");
		return false;
	});

	$("#btn-cancel-title").click(function(){
		$("#box-edit-title").hide();
		$("#box-display-title").fadeIn("slow");
		return false;
	});

	$("#btn-submit-title").click(function(){
		var title = $("#box-edit-title textarea").val();

		$.ajax({
			method: "post",
			url: "page/update_page_title",
			data: {page_id: 1, title: title},
			success:function(data){
				if(data==="success"){
					$("#box-edit-title").hide();
					$("#box-display-title span").text(title);
					$("#box-display-title").fadeIn("slow");
				}
				else{
					alert("an error occured!");
				}
				return false;
			}
		});
	});

	// keywords
	$("#text-edit-keywords").click(function(){
		$("#box-display-keywords").hide();
		$("#box-edit-keywords").fadeIn("slow");
		return false;
	});

	$("#btn-cancel-keywords").click(function(){
		$("#box-edit-keywords").hide();
		$("#box-display-keywords").fadeIn("slow");
		return false;
	});

	$("#btn-submit-keywords").click(function(){
		var keywords = $("#box-edit-keywords textarea").val();

		$.ajax({
			method: "post",
			url: "page/update_page_keywords",
			data: {page_id: 1, keywords: keywords},
			success:function(data){
				if(data==="success"){
					$("#box-edit-keywords").hide();
					$("#box-display-keywords span").text(keywords);
					$("#box-display-keywords").fadeIn("slow");
				}
				else{
					alert("an error occured!");
				}
				return false;
			}
		});
	});

	// description
	$("#text-edit-description").click(function(){
		$("#box-display-description").hide();
		$("#box-edit-description").fadeIn("slow");
		return false;
	});

	$("#btn-cancel-description").click(function(){
		$("#box-edit-description").hide();
		$("#box-display-description").fadeIn("slow");
		return false;
	});

	$("#btn-submit-description").click(function(){
		var description = $("#box-edit-description textarea").val();

		$.ajax({
			method: "post",
			url: "page/update_page_description",
			data: {page_id: 1, description: description},
			success:function(data){
				if(data==="success"){
					$("#box-edit-description").hide();
					$("#box-display-description span").text(description);
					$("#box-display-description").fadeIn("slow");
				}
				else{
					alert("an error occured!");
				}
				return false;
			}
		});
	});

	// peserta
	$("#text-add-peserta").click(function(){
		$("#form_action").val("create");
		$("#peserta_id").val("");
		$("#box-table-peserta").hide();
		$("#box-form-slider").fadeIn("slow");
		return false;
	});

	$(".text-detail-peserta").click(function(){
		var peserta_id = $(this).attr("data-peserta-id");

		$.ajax({
			method: "post",
			url: "peserta/detail_peserta",
			data: {peserta_id: peserta_id},
			success:function(data){
				peserta = data.split("|");
				$("#kategori").text("Kepala Laboratorium "+peserta[0]);
				$("#nama_lengkap").text(peserta[1]);
				$("#nidn_nip").text(peserta[2]);
				$("#tempat").text(peserta[3]);
				$("#tanggal_lahir").text(peserta[4]);
				$("#alamat").text(peserta[5]);
				$("#instansi").text(peserta[6]);
				$("#alamat_instansi").text(peserta[7]);
				$("#no_telepon").text(peserta[8]);
				$("#no_handphone").text(peserta[9]);
				$("#email").text(peserta[10]);
				$("#surat_tugas").attr("href", "../uploads/pendaftaran/"+peserta[11]);
				$("#informasi_laboratorium_sekolah").attr("href", "../uploads/pendaftaran/"+peserta[12]);
				$("#periode_pelatihan").text(peserta[13]);
				$("#foto").attr("src", "../uploads/pendaftaran/"+peserta[14]);
				$("#status").text(peserta[15]);
				$("#tanggal_dibuat").text(peserta[16]);
				$("#bukti_pembayaran").attr("src", "../uploads/bukti_pembayaran/"+peserta[17]);
				$("#tanggal_konfirmasi").text(peserta[18]);
				$("#tanggal_disetujui").text(peserta[19]);
				if(peserta[15] === "approved"){
					$(".text-approve-peserta").hide();
				}
				$(".text-approve-peserta").attr("data-peserta-id", peserta_id);
				$("#box-table-peserta").hide();
				$("#box-detail-peserta").fadeIn("slow");
			}
		});
	});

	$(".text-back-to-table").click(function(){
			$("#kategori").text("");
			$("#nama_lengkap").text("");
			$("#nidn_nip").text("");
			$("#tempat").text("");
			$("#tanggal_lahir").text("");
			$("#alamat").text("");
			$("#instansi").text("");
			$("#alamat_instansi").text("");
			$("#no_telepon").text("");
			$("#no_handphone").text("");
			$("#email").text("");
			$("#surat_tugas").attr("href", "");
			$("#informasi_laboratorium_sekolah").attr("");
			$("#periode_pelatihan").text("");
			$("#foto").attr("src", "");
			$("#status").text("");
			$("#tanggal_dibuat").text("");
			$("#bukti_pembayaran").attr("src", "");
			$("#tanggal_konfirmasi").text("");
			$("#tanggal_disetujui").text("");
			$(".text-approve-peserta").show();
			$("#box-detail-peserta").hide();
			$("#box-table-peserta").fadeIn("slow");
	});

	$(".text-edit-peserta").click(function(){
		$("#form_action").val("update");
		var peserta_id = $(this).attr("data-peserta-id");
		$("#peserta_id").val(peserta_id);

		$.ajax({
			method: "post",
			url: "peserta/edit_peserta",
			data: {peserta_id: peserta_id},
			success:function(data){
				peserta = data.split("|");
				$("#kategori").text("Kepala Laboratorium "+peserta[0]);
				$("#nama_lengkap").text(peserta[1]);
				$("#nidn_nip").text(peserta[2]);
				$("#tempat").text(peserta[3]);
				$("#tanggal_lahir").text(peserta[4]);
				$("#alamat").text(peserta[5]);
				$("#instansi").text(peserta[6]);
				$("#alamat_instansi").text(peserta[7]);
				$("#no_telepon").text(peserta[8]);
				$("#no_handphone").text(peserta[9]);
				$("#email").text(peserta[10]);
				$("#surat_tugas").attr("href", "../uploads/pendaftaran/"+peserta[11]);
				$("#informasi_laboratorium_sekolah").attr("href", "../uploads/pendaftaran/"+peserta[12]);
				$("#periode_pelatihan").text(peserta[13]);
				$("#foto").attr("src", "../uploads/pendaftaran/"+peserta[14]);
				$("#status").text(peserta[15]);
				$("#tanggal_dibuat").text(peserta[16]);
				$("#bukti_pembayaran").attr("src", "../uploads/bukti_pembayaran/"+peserta[17]);
				$("#tanggal_konfirmasi").text(peserta[18]);
				$("#tanggal_disetujui").text(peserta[19]);
				if(peserta[15] === "approved"){
					$(".text-approve-peserta").hide();
				}
				$(".text-approve-peserta").attr("data-peserta-id", peserta_id);
				$("#box-table-peserta").hide();
				$("#box-detail-peserta").fadeIn("slow");
			}
		});
	});

	$(".text-approve-peserta").click(function(){
		var peserta_id = $(this).attr("data-peserta-id");
		var confirmation = confirm("Are you sure you want to approve this peserta ?")

		if(confirmation === true){
			$.ajax({
				method: "post",
				url: "peserta/approve_peserta",
				data: {peserta_id: peserta_id},
				success:function(data){
					if(data==="success"){
						alert("peserta approved");
						window.location.reload();
					}
					else{
						alert("an error occured!");
					}
				}
			});
		}
	});

	$(".text-delete-peserta").click(function(){
		var peserta_id = $(this).attr("data-peserta-id");
		var confirmation = confirm("Are you sure you want to delete this peserta ?")

		if(confirmation === true){
			$.ajax({
				method: "post",
				url: "peserta/delete_peserta",
				data: {peserta_id: peserta_id},
				success:function(data){
					if(data==="success"){
						alert("peserta deleted");
						window.location.reload();
					}
					else{
						alert("an error occured!");
					}
				}
			});
		}
	});

	$("#btn-submit-peserta").click(function(){
		var kategori = $('#kategori').val();
		var nama_lengkap = $('#nama_lengkap').val();
		var nidn_nip = $('#nidn_nip').val();
		var tempat = $('#tempat').val();
		var tanggal_lahir = $('#tanggal_lahir').val();
		var alamat = $('#alamat').val();
		var instansi = $('#instansi').val();
		var alamat_instansi = $('.alamat_instansi').val();
		var no_handphone = $('.no_handphone').val();
		var no_telepon = $('.no_telepon').val();
		var email = $('#email').val();
		var surat_tugas = $('#surat_tugas').val();
		var informasi_laboratorium_sekolah = $('#informasi_laboratorium_sekolah').val();
		var periode_pelatihan = $('#email').val();
		var status = $('#status').val();
		var form_action = $('#form_action').val();

		if(kategori === "" || nama_lengkap === "" || nidn_nip === "" || tempat === "" || tanggal_lahir === "" || alamat === "" || instansi === "" || alamat_instansi === "" || no_handphone === "" || no_telepon === "" || email === "" || surat_tugas === "" || informasi_laboratorium_sekolah === "" || periode_pelatihan === "" || status === "" || form_action === ""){
			$(".alert").slideDown();
			setTimeout(function(){
				$(".alert").slideUp();
			}, 3000);
			return false;
		}
		else{
			return true;
		}

		// if(form_action === "create"){
		// 	$.ajax({
		// 		method: "post",
		// 		url: "peserta/create_new_peserta",
		// 		data: {title: title, keywords: keywords, description: description, thumbnail: thumbnail, content: content, promo: promo},
		// 		success:function(data){
		// 			if(data==="success"){
		// 				alert("success");
		// 			}
		// 			else{
		// 				alert("an error occured!");
		// 			}
		// 		}
		// 	});
		// }
		// else{
		// 	var peserta_id = $("#peserta_id").val();
		// 	$.ajax({
		// 		method: "post",
		// 		url: "peserta/update_peserta",
		// 		data: {peserta_id: peserta_id, title: title, keywords: keywords, description: description, thumbnail: thumbnail, content: content, promo: promo},
		// 		success:function(data){
		// 			if(data==="success"){
		// 				alert("success");
		// 			}
		// 			else{
		// 				alert("an error occured!");
		// 			}
		// 		}
		// 	});
		// }
	});

	$("#btn-cancel-peserta").click(function(){
		$("#box-form-slider").hide();
		$("#box-table-peserta").fadeIn("slow");
		return false;
	});

	$("#btn-choose-thumbnail").click(function(){
		$("#thumbnail_path").click();
		return false;
	});
});